# Fake_Note_Detection
Fake Note Detection using TensorFlow in Python

I used the [Bank Authentication Data Set](https://archive.ics.uci.edu/ml/datasets/banknote+authentication) from the UCI repository.

# Exploratory data analysis

![download](https://user-images.githubusercontent.com/12499006/31045622-971ec2d4-a605-11e7-8c0b-47e656e5ff78.png)

# Model Evaluation

![capture](https://user-images.githubusercontent.com/12499006/32700128-aaf01e5e-c7e6-11e7-8032-c83503ebba60.PNG)


